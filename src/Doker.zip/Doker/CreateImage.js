import React from 'react'
import { connect } from 'react-redux'

export const CreateImage = (props) => {
  return (
    <div>CreateImage</div>
  )
}

const mapStateToProps = (state) => ({})

const mapDispatchToProps = {}

export default connect(mapStateToProps, mapDispatchToProps)(CreateImage)